Link zur Visual Novel: https://samuelkasper.github.io/VisualNovelEndabgabe/Endabgabe/index.html

Link zum Repository: https://github.com/SamuelKasper/VisualNovelEndabgabe

Link zum Code: https://github.com/SamuelKasper/VisualNovelEndabgabe/tree/main/Endabgabe/Source

Link zum Konzept: https://github.com/SamuelKasper/VisualNovelEndabgabe/tree/main/Endabgabe/Konzept

