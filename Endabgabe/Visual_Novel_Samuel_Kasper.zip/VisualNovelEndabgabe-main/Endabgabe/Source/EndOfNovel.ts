namespace Endabgabe {
    export async function EndOfNovel(): fS.SceneReturn { /**/}
}